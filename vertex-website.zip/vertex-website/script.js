/* Vertex Engineering Services Limited — site behaviour */
(function () {
  'use strict';

  /* Mobile menu */
  var toggle = document.querySelector('.menu-toggle');
  var nav = document.getElementById('nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
  document.querySelectorAll('.sub-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var li = btn.parentElement;
      var open = li.classList.toggle('open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && nav && nav.classList.contains('open')) {
      nav.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.focus();
    }
  });

  /* Footer year */
  var y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  /* Hero slider */
  var hero = document.querySelector('.hero');
  if (!hero) return;
  var slides = Array.prototype.slice.call(hero.querySelectorAll('.slide'));
  var dots = Array.prototype.slice.call(hero.querySelectorAll('.dot'));
  var live = hero.querySelector('.slide-live');
  var pauseBtn = hero.querySelector('.ctl-pause');
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var INTERVAL = 6000;
  var index = 0, timer = null, userPaused = reduce, hoverPaused = false;

  function show(i, announce) {
    index = (i + slides.length) % slides.length;
    slides.forEach(function (s, n) {
      var on = n === index;
      s.classList.toggle('is-active', on);
      s.setAttribute('aria-hidden', on ? 'false' : 'true');
      Array.prototype.forEach.call(s.querySelectorAll('a'), function (a) {
        a.tabIndex = on ? 0 : -1;
      });
    });
    dots.forEach(function (d, n) { d.setAttribute('aria-current', n === index ? 'true' : 'false'); });
    if (announce && live) live.textContent = 'Slide ' + (index + 1) + ' of ' + slides.length + ': ' + slides[index].querySelector('h2').textContent;
    restart();
  }
  function running() { return !userPaused && !hoverPaused; }
  function restart() {
    clearTimeout(timer);
    hero.classList.remove('playing');
    if (running()) {
      void hero.offsetWidth; /* restart the progress bar */
      hero.classList.add('playing');
      timer = setTimeout(function () { show(index + 1, false); }, INTERVAL);
    }
  }
  hero.querySelector('.ctl-prev').addEventListener('click', function () { show(index - 1, true); });
  hero.querySelector('.ctl-next').addEventListener('click', function () { show(index + 1, true); });
  dots.forEach(function (d, n) { d.addEventListener('click', function () { show(n, true); }); });
  function syncPause() {
    pauseBtn.setAttribute('aria-pressed', userPaused ? 'true' : 'false');
    pauseBtn.setAttribute('aria-label', userPaused ? 'Resume slideshow' : 'Pause slideshow');
    pauseBtn.querySelector('.i-pause').style.display = userPaused ? 'none' : 'block';
    pauseBtn.querySelector('.i-play').style.display = userPaused ? 'block' : 'none';
  }
  pauseBtn.addEventListener('click', function () { userPaused = !userPaused; syncPause(); restart(); });
  hero.addEventListener('mouseenter', function () { hoverPaused = true; restart(); });
  hero.addEventListener('mouseleave', function () { hoverPaused = false; restart(); });
  hero.addEventListener('focusin', function () { hoverPaused = true; restart(); });
  hero.addEventListener('focusout', function () { hoverPaused = false; restart(); });
  hero.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowLeft') { show(index - 1, true); }
    if (e.key === 'ArrowRight') { show(index + 1, true); }
  });
  /* Touch swipe */
  var x0 = null;
  hero.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
  hero.addEventListener('touchend', function (e) {
    if (x0 === null) return;
    var dx = e.changedTouches[0].clientX - x0;
    if (Math.abs(dx) > 45) show(index + (dx < 0 ? 1 : -1), true);
    x0 = null;
  }, { passive: true });
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { clearTimeout(timer); hero.classList.remove('playing'); } else { restart(); }
  });
  syncPause();
  show(0, false);
})();

/* Enquiry forms: friendly status after submit (Formspree / Netlify style POST) */
document.querySelectorAll('form[data-enquiry]').forEach(function (form) {
  form.addEventListener('submit', function (e) {
    var status = form.querySelector('.form-status');
    var action = form.getAttribute('action') || '';
    if (action.indexOf('YOUR_FORM_ID') !== -1) {
      e.preventDefault();
      status.textContent = 'This form is not connected yet. Add your form endpoint in the form action (see README).';
      return;
    }
    if (!window.fetch) return; /* fall back to normal submit */
    e.preventDefault();
    status.textContent = 'Sending…';
    fetch(action, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } })
      .then(function (r) {
        if (r.ok) {
          form.reset();
          status.textContent = 'Thank you for contacting Vertex Engineering Services Limited. Your enquiry has been received. Our team will review the details and contact you using the information provided.';
        } else { status.textContent = 'Your enquiry was not sent. Please check the fields and try again.'; }
      })
      .catch(function () { status.textContent = 'Your enquiry was not sent. Check your connection and try again.'; });
  });
});
